# naPINN: supplementary code

Code for the submission *naPINN: Noise-Adaptive Physics-Informed Neural Networks
for Recovering Physics from Corrupted Measurements*.

naPINN learns the distribution of measurement residuals during training and
uses it, through a trainable gate and a rejection cost, to weight each
measurement in the data loss of an inverse PINN.

## Setup

```bash
pip install -r requirements.txt
```

All commands are run from this directory. The experiments use one CUDA GPU.
Results are written under `outputs/`.

## Layout

```text
pinnlab/                 method implementation
  utils/ebm.py           EBM density estimator and the trainable gate
  utils/density.py       estimator factory (EBM, Gaussian mixture, KDE)
  utils/kde.py           kernel density estimator
  utils/data_loss.py     MSE, L1 and q-Gaussian data losses
  experiments/           PDE benchmarks (Allen-Cahn, Burgers, lambda-omega, real PIV)
  models/                MLP and variational Bayesian PINN
  simulation/            reference-solution generators (Burgers, lambda-omega)
  data/noise.py          background-noise distributions
configs/
  paper/                 settings of the simulated-benchmark runs in the paper
  paper/realpdebench_multidataset/   additional RealPDEBench scenarios
  experiment/            PDE and real-PIV experiment configurations
  model/                 network configurations
scripts/
  experiments/           runners, data preparation and corruption injection
  simulation/            reference-data generation
  mlp/, bpinn/           launchers for the generic training entry point
analysis/evaluate_checkpoint.py      reload a checkpoint and evaluate it
```

## Simulated benchmarks

1. Generate the reference solutions for Burgers and lambda-omega. Allen-Cahn
   uses an analytical solution and needs no data.

   ```bash
   bash scripts/simulation/burgers_3.sh
   bash scripts/simulation/lambdaomega.sh
   ```

2. Train one method on one benchmark, for example naPINN on Allen-Cahn with
   15% gross outliers:

   ```bash
   python -m scripts.experiments.run_synthetic \
     --experiment-name allencahn2d --method napinn --seed 40 --device cuda:0 \
     --experiment-config configs/paper/allencahn2d.yaml --outlier-ratio 0.15
   ```

   `--experiment-name` is `allencahn2d`, `burgers2d` or `lambdaomega2d`, with
   the matching file in `configs/paper/`. `--outlier-ratio` is 0.05, 0.10 or
   0.15. Each run writes `metrics.json` with the field errors (rMAE, rMSE), the
   coefficient error and the gate statistics.

   | Method in the paper | `--method` and options |
   | --- | --- |
   | PINN (MSE) | `mse` |
   | LAD-PINN | `lad` |
   | OrPINN, q = 1.9 / 2.9 | `orpinn_q19` / `orpinn_q29` |
   | PINN-EBM | `pinn_ebm --pde-weight 10` |
   | naPINN | `napinn` |
   | naPINN with an L1 / q-Gaussian loss | `napinn_lad` / `napinn_q29` |
   | Gate on residual magnitude, learned cutoff | `threshold` |
   | Fixed 95% residual quantile | `quantile` |
   | Frozen gate | `napinn --freeze-gate` |
   | Pre-training screens | `mse --preprocess-screen {global_z,global_mad,local_median} --preprocess-k K` |
   | Wall-clock-matched baselines | add `--time-budget-seconds T` |

   Sensitivity runs use `--ema-momentum`, `--rejection-cost`,
   `--gate-init-cutoff-sigma` and `--gate-init-steepness`. The two-stage
   MAD-PINN baseline is run with `python -m scripts.experiments.run_synthetic_mad`
   (see `--help`).

3. The variational B-PINN, the alternative estimators and the other noise
   families are trained with the generic entry point, for example

   ```bash
   python -m pinnlab.train --model_name bpinn --experiment_name allencahn2d \
     --common_config configs/common_config.yaml \
     --model_config configs/model/bpinn.yaml \
     --exp_config configs/experiment/allencahn2d.yaml
   ```

   The launchers in `scripts/mlp/` and `scripts/bpinn/` wrap this command. The
   estimator is selected by `ebm.density_estimator` (`ebm`, `gmm` or `kde`) and
   the background noise by `noise.kind` in the experiment configuration.

## Real PIV (RealPDEBench)

The real measurements come from RealPDEBench, release 2.0.0 (CC BY-NC 4.0),
which must be downloaded from its official source.

1. Prepare the Cylinder data from the released Arrow file:

   ```bash
   python -m scripts.experiments.prepare_realpdebench_cylinder --arrow PATH_TO_CYLINDER_ARROW
   ```

2. Inject the gross corruption at 10% and 15% of the training rows for seeds
   40-42:

   ```bash
   for s in 40 41 42; do
     python -m scripts.experiments.inject_realpdebench_legacy_4g --seed $s --ratios 0.10 0.15
   done
   ```

3. Train a method on one corrupted dataset:

   ```bash
   bash scripts/experiments/run_realpdebench.sh napinn 40 cuda:0 \
     configs/experiment/realpdebench_cylinder_legacy4g_seed40_r15_b1_o1.yaml
   ```

   The method is one of `mse`, `lad`, `orpinn_q29`, `pinn_ebm`,
   `pinn_ebm_weight10`, `pinn_ebm_equal_weight`, `napinn`, `napinn_lad` and
   `napinn_q29`.

4. For the additional scenarios (Controlled Cylinder, FSI and Foil), place the
   released Arrow files in `outputs/realpdebench_multidataset/source/` under
   the names listed in `scripts/experiments/prepare_realpdebench_multidataset.py`,
   then run

   ```bash
   python -m scripts.experiments.prepare_realpdebench_multidataset --scenario all
   for s in 40 41 42; do
     python -m scripts.experiments.inject_realpdebench_multidataset --scenario all --seed $s
   done
   python -m scripts.experiments.run_realpdebench \
     --common-config configs/paper/realpdebench_multidataset/common.yaml \
     --model-config configs/model/mlp.yaml \
     --exp-config configs/paper/realpdebench_multidataset/napinn_mse.yaml \
     --variant-config configs/paper/realpdebench_multidataset/data/fsi_seed40_r10.yaml \
     --seed 40 --device cuda:0
   ```

## Default naPINN settings

All naPINN runs use 5,000 warm-up updates, 5,000 estimator-only updates and
25,000 joint updates, a running-scale weight of 0.05, a gate whose
pre-softplus cutoff and steepness are initialized at 2 and 30 (cutoff about 2.13
after the softplus), and a rejection cost of 0.5.
