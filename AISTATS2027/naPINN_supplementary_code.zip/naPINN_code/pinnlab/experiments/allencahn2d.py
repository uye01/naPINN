# pinnlab/experiments/allencahn2d.py
import math, os
import sys
from sklearn.metrics import confusion_matrix
import seaborn as sns
import torch
import numpy as np
from matplotlib import pyplot as plt
import imageio
from tqdm import trange
from pinnlab.experiments.base import BaseExperiment, make_leaf, grad_sum
from pinnlab.data.geometries import Rectangle, linspace_2d
from pinnlab.data.noise import get_noise
from analysis.plotting import save_plots_2d
from pinnlab.utils.ebm import (
    LearnableThresholdGate,
    QuantileThresholdGate,
    TrainableLikelihoodGate,
)
from pinnlab.utils.density import create_density_estimator
from pinnlab.utils.data_loss import (
    data_loss_mse,
    data_loss_l1,
    data_loss_q_gaussian,
)

class AllenCahn2D(BaseExperiment):
    r"""
    Allen–Cahn (2D, time-dependent) with manufactured forcing:

        u_t - ε^2 (u_xx + u_yy) + (u^3 - u) = f(x,y,t),  (x,y)∈[xa,xb]×[ya,yb], t∈[t0,t1]

    Manufactured solution:
        u*(x,y,t) = sin(π x) sin(π y) cos(ω t)

    Then
        f = u*_t - ε^2 Δu* + (u*^3 - u*)
    cfg:
      domain: {x: [xa, xb], y: [ya, yb], t: [t0, t1]}
      eps: 0.01
      omega: 2.0
    """

    def __init__(self, cfg, device):
        super().__init__(cfg, device)
        self.device = device
        
        xa, xb = cfg["domain"]["x"]; ya, yb = cfg["domain"]["y"]
        self.t0, self.t1 = cfg["domain"]["t"]
        self.rect  = Rectangle(xa, xb, ya, yb, device)
        
        # PDE parameters
        self.pde_cfg = cfg.get("pde", {}) or {}
        self.true_eps = float(self.pde_cfg.get("eps", 0.01))
        self.true_omega = float(self.pde_cfg.get("omega", 2.0))
        self.learn_eps = self.pde_cfg.get("learn_eps", True)
        
        if self.learn_eps:
            init_eps = float(self.pde_cfg.get("init_eps", 0.0))
            print(f"[AllenCahn2D] PDE Parameter ε (eps) is TRAINABLE. Init: {init_eps}, True: {self.true_eps}")
            self.eps = torch.nn.Parameter(torch.tensor(init_eps, dtype=torch.float32, device=device))
        else:
            print(f"[AllenCahn2D] PDE Parameter ε (eps) is FIXED. Value: {self.true_eps}")
            self.eps = self.true_eps
            
        # set omega fixed for now
        self.omega = self.true_omega
        
        self.sampling_mode = cfg.get("sampling_mode", "random") # random / grid
        if self.sampling_mode == "grid":
            g = cfg.get("grid", {})
            nx, ny, nt = int(g.get("nx", 100)), int(g.get("ny", 100)), int(g.get("nt", 100))
            
            Xg, Yg = linspace_2d(self.rect.xa, self.rect.xb, self.rect.ya, self.rect.yb, nx, ny, device)
            XY = torch.stack([Xg.reshape(-1), Yg.reshape(-1)], dim=1)  # [nx*ny, 2]
            self._XY = XY
            self._T = torch.linspace(self.t0, self.t1, nt, device=device) # [nt]
            
            # boundary subset (any edge)
            xa, xb, ya, yb = self.rect.xa, self.rect.xb, self.rect.ya, self.rect.yb
            mask_b = XY[:,0].eq(xa) | XY[:,0].eq(xb) | XY[:,1].eq(ya) | XY[:,1].eq(yb)
            self._XYb = XY[mask_b]  # [nb, 2]
            
        noise_cfg = cfg.get("noise", None)
        self.use_data = bool(noise_cfg.get("enabled", False))
        self.noise_cfg = noise_cfg
        self.noise_pars = noise_cfg.get("pars", 0)
        self.n_data_total = int(noise_cfg.get("n_train", 0))
        self.n_data_batch = int(noise_cfg.get("batch_size", 1000))
        self.par_list = noise_cfg.get("par_list", None)
        
        self.extra_noise_cfg = noise_cfg.get("extra_noise", {})
        self.use_extra_noise = bool(self.extra_noise_cfg.get("enabled", False))
        self.extra_noise_mask = None
        self.outlier_kind = self.extra_noise_cfg.get("kind", "std")  # 'std' or 'mean_level'
        # 'additive' (default) adds a positive offset, as in the paper;
        # 'replacement' substitutes the observation. See _init_noisy_dataset.
        self.outlier_mode = self.extra_noise_cfg.get("outlier_mode", "additive")
        print(f"[AllenCahn2D] use_extra_noise = {self.use_extra_noise}")
        
        self.X_data = None
        self.y_data = None
        self.y_clean = None
        self.noise_model = None
        
        if self.use_data and self.n_data_total > 0:
            self._init_noisy_dataset()

        ebm_cfg = cfg.get("ebm", {}) or {}
        self.use_ebm = bool(ebm_cfg.get("enabled", False))
        self.ebm_init_train_epochs = int(ebm_cfg["init_train_epochs"])
        
        # running_std is needed for residual scaling (used by EBM and ablation gates)
        self.running_std = torch.tensor(1.0, device=device)
        self.std_mode = ebm_cfg.get("std_mode", "ema")  # "ema" | "batch"
        self.momentum = float(ebm_cfg.get("momentum", 0.05))

        if self.use_ebm:
            self.ebm = create_density_estimator(ebm_cfg, input_dim=1, device=device)
        else:
            self.ebm = None

        self.use_phase = bool(cfg.get("phase", {}).get("enabled", False))
        
        data_loss_cfg = cfg.get("data_loss", {}) or {}
        self.data_loss_kind = data_loss_cfg.get("kind", "mse")       
        # q-Gaussian settings
        self.q_gauss_q = float(data_loss_cfg.get("q", 1.2))
        beta_val = data_loss_cfg.get("beta", None)
        self.q_gauss_beta = float(beta_val) if beta_val is not None else None
        
        data_lb_cfg = cfg.get("data_loss_balancer", {})
        self.use_data_loss_balancer = bool(data_lb_cfg.get("use_loss_balancer", False))
        self.data_loss_balancer_kind = data_lb_cfg.get("kind", "gated_trainable")
        
        self.gate_module = None
        if self.use_data_loss_balancer and self.data_loss_balancer_kind == "gated_trainable":
            self.rejection_cost = float(data_lb_cfg.get("rejection_cost", 0.5))
            # Distinct key names: the pre-existing ``init_steepness`` key
            # belongs to LearnableThresholdGate, and reusing it here would
            # silently change every completed gated_trainable run. Absent
            # keys fall back to the constructor values used so far.
            self.gate_module = TrainableLikelihoodGate(
                device=device,
                rejection_cost=self.rejection_cost,
                init_cutoff_sigma=float(
                    data_lb_cfg.get("gate_init_cutoff_sigma", 2.0)
                ),
                init_steepness=float(
                    data_lb_cfg.get("gate_init_steepness", 30.0)
                ),
            )

        # --- Ablation 1: Quantile thresholding (no EBM) ---
        self.quantile_gate = None
        if self.use_data_loss_balancer and self.data_loss_balancer_kind == "quantile":
            self.quantile_gate = QuantileThresholdGate(
                quantile=float(data_lb_cfg.get("quantile", 0.95)),
                steepness=float(data_lb_cfg.get("steepness", 10.0)),
                device=device,
            )
            print(f"[AllenCahn2D] Ablation 1: QuantileThresholdGate "
                  f"(q={data_lb_cfg.get('quantile', 0.95)}, steepness={data_lb_cfg.get('steepness', 10.0)})")

        # --- Ablation 2: Learnable threshold (no EBM, no gate) ---
        self.threshold_gate = None
        if self.use_data_loss_balancer and self.data_loss_balancer_kind == "threshold":
            self.threshold_gate = LearnableThresholdGate(
                init_threshold=float(data_lb_cfg.get("init_threshold", 1.0)),
                init_steepness=float(data_lb_cfg.get("init_steepness", 10.0)),
                rejection_cost=float(data_lb_cfg.get("rejection_cost", 0.5)),
                device=device,
            )
            print(f"[AllenCahn2D] Ablation 2: LearnableThresholdGate "
                  f"(init_tau={data_lb_cfg.get('init_threshold', 1.0)}, rejection_cost={data_lb_cfg.get('rejection_cost', 0.5)})")

        print(f"[AllenCahn2D] use_ebm = {self.use_ebm}")
        print(f"[AllenCahn2D] use_phase = {self.use_phase}")
        print(f"[AllenCahn2D] data_loss_kind = {self.data_loss_kind}")
        print(f"[AllenCahn2D] use_data_loss_balancer = {self.use_data_loss_balancer}")
        print(f"[AllenCahn2D] data_loss_balancer_kind = {self.data_loss_balancer_kind}")
            
    def state_dict(self):
        state = {'running_std': self.running_std}
        if self.learn_eps:
            state['eps'] = self.eps

        if self.use_ebm and self.ebm is not None:
            state['ebm'] = self.ebm.state_dict()
            state['ebm_optimizer'] = self.ebm.optimizer.state_dict()

        # Save Gate state if it exists
        if self.gate_module is not None:
            state['gate_module'] = self.gate_module.state_dict()

        if self.threshold_gate is not None:
            state['threshold_gate'] = self.threshold_gate.state_dict()

        return state
    
    def load_state_dict(self, state_dict):
        """
        Loads the experiment's optimization state.
        """
        if 'running_std' in state_dict:
            self.running_std.copy_(state_dict['running_std'].to(self.device))
            print(f"[AllenCahn2D] Loaded running_std: {self.running_std.item():.4f}")
            
        if 'eps' in state_dict and self.learn_eps:
            with torch.no_grad():
                self.eps.copy_(state_dict['eps'].to(self.device))
                print(f"[AllenCahn2D] Loaded learned eps: {self.eps.item():.6f}")
                
        if 'ebm' in state_dict and self.ebm is not None:
            self.ebm.load_state_dict(state_dict['ebm'])
            if 'ebm_optimizer' in state_dict:
                self.ebm.optimizer.load_state_dict(state_dict['ebm_optimizer'])
            
        if 'gate_module' in state_dict and self.gate_module is not None:
            self.gate_module.load_state_dict(state_dict['gate_module'])
            
        if 'threshold_gate' in state_dict and self.threshold_gate is not None:
            self.threshold_gate.load_state_dict(state_dict['threshold_gate'])

    # ----- manufactured truth -----
    def u_star(self, x, y, t):
        return torch.sin(math.pi * x) * torch.sin(math.pi * y) * torch.cos(self.omega * t)

    def f(self, x, y, t):
        u   = self.u_star(x, y, t)
        ut  = -self.omega * torch.sin(math.pi * x) * torch.sin(math.pi * y) * torch.sin(self.omega * t)
        lap = -2.0 * (math.pi**2) * self.u_star(x, y, t)  # Δu* = u_xx + u_yy
        return ut - (self.true_eps**2) * lap + (u**3 - u)

    def _init_noisy_dataset(self):
        """
        Generate a fixed set of noisy measurements:
            X_data ~ Uniform(domain x time)
            y_clean = u_star(X_data)
            y_data  = y_clean + epsilon,     epsilon ~ noise distribution (from PINN-EBM)
        """
        kind = self.noise_cfg.get("kind", "4G")
        print(f"[AllenCahn2D] Noise kind: {kind}")
        n = self.n_data_total
        
        sensor_mode = self.noise_cfg.get("sensor_mode", "random") # random / fixed_random / fixed_grid
        
        if sensor_mode == "random":
            XY = self.rect.sample(n)
            print("[AllenCahn2D] Sensor Mode: random")
        elif sensor_mode == "fixed_random":
            n_sensors = int(self.noise_cfg.get("n_sensors", 100))
            print(f"[AllenCahn2D] Sensor Mode: fixed_random with {n_sensors} sensors")
            
            XY_sensors = self.rect.sample(n_sensors)  # [n_sensors, 2]
            
            idx_s = torch.randint(0, n_sensors, (n,), device=self.device)
            XY = XY_sensors[idx_s]  # [n, 2]
        elif sensor_mode == "fixed_grid":
            snx = int(self.noise_cfg.get("sensor_nx", 10))
            sny = int(self.noise_cfg.get("sensor_ny", 10))
            print(f"[AllenCahn2D] Sensor Mode: fixed_grid with {snx}x{sny} sensors")
            
            # Define Grid
            x_s = torch.linspace(self.rect.xa, self.rect.xb, snx, device=self.device)
            y_s = torch.linspace(self.rect.ya, self.rect.yb, sny, device=self.device)
            
            # Create Meshgrid (indexing='ij' ensures x varies along rows, y along cols)
            # We flatten them to list all sensor coordinates
            ys_grid, xs_grid = torch.meshgrid(y_s, x_s, indexing='ij')
            XY_sensors = torch.stack([xs_grid.reshape(-1), ys_grid.reshape(-1)], dim=1) # [N_sensors, 2]
            Ns = XY_sensors.shape[0]
            
            t_grid = self._T.view(-1, 1)
            Nt = t_grid.shape[0]
            
            XY = XY_sensors.repeat_interleave(Nt, dim=0)  # [Ns*Nt, 2]
            t = t_grid.repeat(Ns, 1)                     # [Ns*Nt, 1]
            n = XY.shape[0]

            print(f"XY shape: {XY.shape}")
        else:
            raise ValueError(f"Unknown sensor_mode: {sensor_mode}")

        # Temporal sampling
        X = torch.cat([XY, t], dim=1)  # [n, 3]

        with torch.no_grad():
            u_clean = self.u_star(X[:, 0:1], X[:, 1:2], X[:, 2:3])  # [n, 1]
            
        base_dtype = u_clean.dtype

        # Determine noise scale "f" as in PINN-EBM: a factor times average magnitude of u*
        base_scale = float(self.noise_cfg.get("scale", 0.1))  # relative to mean |u|
        mean_level = float(u_clean.abs().mean().detach().cpu())
        self.sigma_local = base_scale * mean_level
        
        # Build noise distribution; this uses the PINN-EBM function
        if kind == "4G":
            self.noise_model = get_noise(kind, f=1.0, pars=self.noise_pars, par_list=self.par_list)
        else:
            self.noise_model = get_noise(kind, f=1.0, pars=self.noise_pars)
            
        z = self.noise_model.sample(n).float().to(self.device, dtype=base_dtype).view(-1, 1)  # [n, 1]
        eps = z * self.sigma_local
        noise_std = eps.std(unbiased=True).detach()
        
        # Outliers
        self.extra_noise_mask = torch.zeros(n, dtype=torch.bool)
        replacement_rows = torch.zeros(n, dtype=torch.bool, device=self.device)
        replacement_values = torch.zeros_like(eps)
        if self.use_extra_noise:
            n_extra = int(self.extra_noise_cfg.get("n_points", 0))
            print(f"Adding extra noise to {n_extra} points.")
            idx = torch.randperm(n, device=self.device)[:n_extra]
            self.outlier_indices = idx.cpu().numpy()
            
            scale_min = float(self.extra_noise_cfg.get("scale_min", 5.0))
            scale_max = float(self.extra_noise_cfg.get("scale_max", 10.0))

            # scale factor sampling for each noise point: scale factor ~ Uniform(scale_min, scale_max)
            factors = torch.empty(n_extra, 1, device=self.device, dtype=base_dtype).uniform_(scale_min, scale_max)
            
            if self.outlier_kind == "std":
                amp = factors * noise_std
            else: # "mean_level"
                f_outlier = base_scale * mean_level
                amp = factors * f_outlier
            # Gross outliers are added as a positive offset by default, as in
            # the paper. ``outlier_mode='replacement'`` substitutes the
            # observation instead.
            if self.outlier_mode == "replacement":
                replacement_rows[idx] = True
                replacement_values[idx] = amp
            else:
                eps[idx] += amp

        y_noisy = u_clean + eps
        if self.outlier_mode == "replacement":
            # A replaced reading carries no information about the local true
            # value, so the observation becomes the spurious magnitude itself
            # rather than the true value plus an offset. The corrupted rows,
            # their draw and the background noise are otherwise identical to
            # the additive protocol, which makes the two paired.
            y_noisy = torch.where(replacement_rows.view(-1, 1), replacement_values, y_noisy)

        self.X_data = X
        self.y_clean = u_clean
        self.y_data = y_noisy
        print(f"[Noise Init] {self.y_data.shape[0]} measurements; mean |u|={mean_level:.4f}")

    def _data_loss(self, residual: torch.Tensor) -> torch.Tensor:
        kind = self.data_loss_kind
        if kind == "mse":
            return data_loss_mse(residual)
        elif kind == "L1":
            return data_loss_l1(residual)
        elif kind == "q_gaussian":
            return data_loss_q_gaussian(
                residual,
                q=self.q_gauss_q,
                beta=self.q_gauss_beta,
            )
        return residual.pow(2)

    def _get_weights(self, residual):
        # Note: The 'residual' passed here is ALREADY scaled by the code above
        if self.data_loss_balancer_kind == "quantile" and self.quantile_gate is not None:
            return self.quantile_gate(residual)
        elif self.data_loss_balancer_kind == "threshold" and self.threshold_gate is not None:
            return self.threshold_gate(residual)
        elif self.data_loss_balancer_kind == "gated_trainable" and self.ebm is not None:
            with torch.no_grad():
                log_q = self.ebm(residual.detach())
            return self.gate_module(log_q)
        raise ValueError(
            f"Unsupported data_loss_balancer kind: {self.data_loss_balancer_kind}"
        )

    # ----- batching -----
    def sample_batch(self, n_f: int):
        device = self.rect.device

        XY  = self.rect.sample(n_f)
        t_f = torch.rand(n_f, 1, device=device) * (self.t1 - self.t0) + self.t0
        X_f = torch.cat([XY, t_f], dim=1)

        batch = {"X_f": X_f}
        
        if self.use_data and self.X_data is not None and self.n_data_batch > 0:
            n = self.X_data.size(0)
            k = min(self.n_data_batch, n)
            idx = torch.randint(0, n, (k,), device=self.device)
            batch["X_d"] = self.X_data[idx]
            batch["y_d"] = self.y_data[idx]

        return batch
    
    def initialize_EBM(self, model):
        if self.ebm is None:
            print("[EBM Init] Skipped — no EBM configured.")
            return
        use_tty = sys.stdout.isatty()
        pbar_ebm = trange(
            self.ebm_init_train_epochs,
            desc="Initialize EBM",
            ncols=120,
            dynamic_ncols=True,
            leave=False,
            disable=not use_tty
        )
        n_data = self.X_data.shape[0]
        k = min(self.n_data_batch, n_data)
        print("[EBM Init] Training EBM on initial residuals...")
        for ep in pbar_ebm:
            idx_d = torch.randint(0, n_data, (k,), device=self.device)
            X_d = self.X_data[idx_d]
            y_d = self.y_data[idx_d]
            pred = model(X_d)
            residual = y_d - pred
            with torch.no_grad():
                batch_std = residual.std()
                if self.std_mode == "ema":
                    current_std_clamped = torch.clamp(batch_std, min=1e-6, max=self.running_std * 10)
                    self.running_std.mul(1 - self.momentum).add_(current_std_clamped * self.momentum)
                    std_for_scale = self.running_std
                else:  # "batch"
                    std_for_scale = torch.clamp(batch_std, min=1e-6)
                    self.running_std.fill_(std_for_scale)
            residual_scaled = residual / std_for_scale
            nll_ebm, nll_ebm_mean = self.ebm.train_step(residual_scaled.detach())

    # ----- losses -----
    def pde_residual_loss(self, model, batch):
        X = make_leaf(batch["X_f"])                # (x,y,t)
        x, y, t = X[:,0:1], X[:,1:2], X[:,2:3]
        u   = model(X)
        du  = grad_sum(u, X)                       # (u_x, u_y, u_t)
        u_x, u_y, u_t = du[:,0:1], du[:,1:2], du[:,2:3]
        d2u_x = grad_sum(u_x, X)                   # (u_xx, u_xy, u_xt)
        d2u_y = grad_sum(u_y, X)                   # (u_yx, u_yy, u_yt)
        u_xx, u_yy = d2u_x[:,0:1], d2u_y[:,1:2]
        res = u_t - (self.eps**2) * (u_xx + u_yy) + (u**3 - u) - self.f(x, y, t)
        return res.pow(2)

    def data_loss(self, model, batch, phase=1):
        if "X_d" not in batch or "y_d" not in batch:
            return torch.tensor(0.0, device=self.device)

        X_d = batch["X_d"] # [N,3]
        y_d = batch["y_d"] # [N,1] noisy measurements

        pred = model(X_d)  # [N, 1]

        # Residuals for data and for EBM
        residual = (y_d - pred)       # [N, 1] (data - model), used as "noise"
        data_loss_value = self._data_loss(residual) # per-point losses [N, 1]
        
        with torch.no_grad():
            batch_std = residual.std()

            if model.training and phase!=1:
                if self.std_mode == "ema":
                    current_std_clamped = torch.clamp(batch_std, min=1e-6, max=self.running_std * 10)
                    self.running_std.mul_(1 - self.momentum).add_(current_std_clamped * self.momentum)
                    std_for_scale = self.running_std
                else:  # "batch"
                    std_for_scale = torch.clamp(batch_std, min=1e-6)
                    self.running_std.fill_(std_for_scale)
            else:
                std_for_scale = self.running_std

        residual_scaled = residual / std_for_scale
        
        if phase == 0:
            if self.ebm is not None and residual.numel() > 0:
                _, nll_ebm_mean = self.ebm.train_step(residual_scaled.detach())
                batch["ebm_nll"] = nll_ebm_mean

            if self.use_data_loss_balancer:
                # Query weights using SCALED residuals
                w, gate_reg_loss = self._get_weights(residual_scaled.detach())
                weighted_loss = (w * data_loss_value).mean()
                total_loss = weighted_loss + gate_reg_loss
            else:
                total_loss = data_loss_value.mean()
            return total_loss
            
        elif phase == 1:
            return data_loss_value.mean()
        
        elif phase == 2:
            if self.ebm is not None:
                _, nll_ebm_mean = self.ebm.train_step(residual_scaled.detach())
                batch["ebm_nll"] = nll_ebm_mean

            if self.use_data_loss_balancer:
                # Query weights using SCALED residuals
                w, gate_reg_loss = self._get_weights(residual_scaled.detach())
                self._last_n_filtered = int((w < 0.5).sum().item())
                self._last_n_total = w.numel()
                weighted_loss = (w * data_loss_value).mean()
                total_loss = weighted_loss + gate_reg_loss
            else:
                total_loss = data_loss_value.mean()
            return total_loss

        return torch.tensor(0.0, device=self.device)

    def extra_params(self):
        params = []
        if isinstance(self.eps, torch.nn.Parameter):
            params.append(self.eps)
        if getattr(self, "gate_module", None) is not None:
            params.extend(list(self.gate_module.parameters()))
        if getattr(self, "threshold_gate", None) is not None:
            params.extend(list(self.threshold_gate.parameters()))
        return params

    # ----- eval / plots -----
    def eval_on_grid(self, model, grid_cfg):
        model.eval()
        nx, ny, nt = grid_cfg["nx"], grid_cfg["ny"], grid_cfg["nt"]
        Xg, Yg = linspace_2d(self.rect.xa, self.rect.xb, self.rect.ya, self.rect.yb, nx, ny, self.rect.device)
        ts = torch.linspace(self.t0, self.t1, nt, device=self.rect.device)
        idxs = [0, nt//2, nt-1] if nt >= 3 else list(range(nt))
        rMAE_list, rMSE_list = [], []
        with torch.no_grad():
            for ti in idxs:
                T = torch.full_like(Xg, ts[ti])
                XYT = torch.stack([Xg.reshape(-1), Yg.reshape(-1), T.reshape(-1)], dim=1)
                U_pred = model(XYT).reshape(nx, ny)
                U_true = self.u_star(Xg, Yg, T)
                
                diff = (U_pred - U_true).reshape(-1)
                true_flat = U_true.reshape(-1)
                # rMAE
                mae = diff.abs().mean()
                denom_mae = true_flat.abs().mean()
                rmae = mae / denom_mae
                # rMSE
                rmse = torch.sqrt((diff**2).mean())
                denom_rmse = torch.sqrt((true_flat**2).mean())
                rrmse = rmse / denom_rmse
                
                rMAE_list.append(rmae.item())
                rMSE_list.append(rrmse.item())
        return {"rMAE": float(np.mean(rMAE_list)), "rMSE": float(np.mean(rMSE_list))}

    def plot_final(self, model, grid_cfg, out_dir):
        nx, ny, nt = grid_cfg["nx"], grid_cfg["ny"], grid_cfg["nt"]
        Xg, Yg = linspace_2d(self.rect.xa, self.rect.xb, self.rect.ya, self.rect.yb, nx, ny, self.rect.device)
        ts = torch.linspace(self.t0, self.t1, nt, device=self.rect.device)
        figs = {}
        with torch.no_grad():
            for label, ti in zip(["t0","tmid","t1"], [0, nt//2, nt-1]):
                T = torch.full_like(Xg, ts[ti])
                XYT = torch.stack([Xg.reshape(-1), Yg.reshape(-1), T.reshape(-1)], 1)
                U_pred = model(XYT).reshape(nx, ny).cpu().numpy()
                U_true = self.u_star(Xg, Yg, T).cpu().numpy()
                figs.update(save_plots_2d(Xg.cpu().numpy(), Yg.cpu().numpy(), U_true, U_pred, out_dir, f"allencahn2d_{label}"))
        return figs
    
    def make_video(self, model, grid, out_dir, fps=10, filename="final_evolution.mp4", phase=0):
        os.makedirs(out_dir, exist_ok=True)
        frame_dir_name = filename.replace(".mp4", "_frames")
        frames_dir = os.path.join(out_dir, frame_dir_name)
        os.makedirs(frames_dir, exist_ok=True)
        
        nx = int(grid.get("nx", 100))
        ny = int(grid.get("ny", 100))
        nt = int(grid.get("nt", 100))

        # Build spatial grid
        Xg, Yg = linspace_2d(
            self.rect.xa, self.rect.xb,
            self.rect.ya, self.rect.yb,
            nx, ny, self.rect.device
        )
        ts = torch.linspace(self.t0, self.t1, nt, device=self.rect.device)

        extent = [float(self.rect.xa), float(self.rect.xb),
                float(self.rect.ya), float(self.rect.yb)]

        # Check if we have a noise model
        has_noise_model = getattr(self, "noise_model", None) is not None

        # ---------- First pass: determine global color ranges ----------
        vmin, vmax = None, None
        err_max = 0.0

        model.eval()
        with torch.no_grad():
            for tval in ts:
                T = torch.full_like(Xg, tval)
                XYT = torch.stack(
                    [Xg.reshape(-1), Yg.reshape(-1), T.reshape(-1)], dim=1
                )  # [nx*ny, 3]

                U_pred = model(XYT).reshape(nx, ny)    # [nx, ny]
                U_true = self.u_star(Xg, Yg, T)        # [nx, ny]

                if has_noise_model:
                    eps = self.noise_model.sample(nx * ny).to(self.rect.device)
                    eps = eps.view(nx, ny)
                    U_noisy = U_true + eps
                else:
                    U_noisy = U_true

                # Global color range for all "solution-like" panels
                umin = min(U_true.min().item(), U_pred.min().item())
                umax = max(U_true.max().item(), U_pred.max().item())
                vmin = umin if vmin is None else min(vmin, umin)
                vmax = umax if vmax is None else max(vmax, umax)

                # Error scale
                err_max = max(err_max, (U_true - U_pred).abs().max().item())
                # print(f"err_max: {err_max}")

        # Safety
        if err_max <= 0:
            err_max = 1e-6

        force_vmax = 0.283
        # ---------- Second pass: render frames ----------
        frames = []
        with torch.no_grad():
            for tval in ts:
                T = torch.full_like(Xg, tval)
                XYT = torch.stack(
                    [Xg.reshape(-1), Yg.reshape(-1), T.reshape(-1)], dim=1
                )

                U_pred = model(XYT).reshape(nx, ny).cpu().numpy()
                U_true = self.u_star(Xg, Yg, T).cpu().numpy()

                if has_noise_model:
                    eps = self.noise_model.sample(nx * ny).to(self.rect.device)
                    eps = eps.view(nx, ny).cpu().numpy()
                    U_noisy = U_true + eps
                else:
                    U_noisy = U_true  # fallback: no noise → same as true

                U_err = np.abs(U_true - U_pred)

                fig = plt.figure(figsize=(12, 12), dpi=120)
                plt.suptitle(f"t = {float(tval):.5f}")

                # [0,0] Noisy data over whole domain
                ax1 = plt.subplot(2, 2, 1)
                im1 = ax1.imshow(
                    U_noisy.T, origin="lower", extent=extent,
                    vmin=vmin, vmax=vmax, aspect="auto"
                )
                ax1.set_title("Noisy data: u*(x,y,t) + ε")
                ax1.set_xlabel("x"); ax1.set_ylabel("y")
                cbar1 = fig.colorbar(im1, ax=ax1, fraction=0.08, pad=0.04)
                cbar1.ax.tick_params(labelsize=14)

                # [0,1] True solution
                ax2 = plt.subplot(2, 2, 2)
                im2 = ax2.imshow(
                    U_true.T, origin="lower", extent=extent,
                    vmin=vmin, vmax=vmax, aspect="auto"
                )
                ax2.set_title("True solution u*(x,y,t)")
                ax2.set_xlabel("x"); ax2.set_ylabel("y")
                cbar2 = fig.colorbar(im2, ax=ax2, fraction=0.08, pad=0.04)
                cbar2.ax.tick_params(labelsize=14)

                # [1,0] Predicted solution
                ax3 = plt.subplot(2, 2, 3)
                im3 = ax3.imshow(
                    U_pred.T, origin="lower", extent=extent,
                    vmin=vmin, vmax=vmax, aspect="auto"
                )
                ax3.set_title("Predicted solution û(x,y,t)")
                ax3.set_xlabel("x"); ax3.set_ylabel("y")
                cbar3 = fig.colorbar(im3, ax=ax3, fraction=0.08, pad=0.04)
                cbar3.ax.tick_params(labelsize=14)

                # [1,1] Absolute error
                ax4 = plt.subplot(2, 2, 4)
                im4 = ax4.imshow(
                    U_err.T, origin="lower", extent=extent,
                    vmin=0.0, vmax=force_vmax, aspect="auto"
                )
                ax4.set_title("|Error| = |u* - û|")
                ax4.set_xlabel("x"); ax4.set_ylabel("y")
                cbar4 = fig.colorbar(im4, ax=ax4, fraction=0.046, pad=0.04)
                cbar4.ax.tick_params(labelsize=14)

                fig.tight_layout(rect=[0, 0.03, 1, 0.95])
                
                # save PDF frame
                frame_path = os.path.join(frames_dir, f"frame_t{float(tval):.5f}.pdf")
                fig.savefig(frame_path, format='pdf', bbox_inches='tight')

                # Convert figure to frame
                fig.canvas.draw()
                w, h = fig.canvas.get_width_height()
                buf = np.frombuffer(fig.canvas.tostring_rgb(), dtype=np.uint8)
                frame = buf.reshape(h, w, 3)
                frames.append(frame.copy())
                plt.close(fig)

        # ---------- Write video ----------
        ext = os.path.splitext(filename)[1].lower()
        path = os.path.join(out_dir, filename)
        if ext == ".gif":
            imageio.mimsave(path, frames, fps=fps)
        elif ext == ".mp4":
            writer = imageio.get_writer(path, fps=fps, codec="libx264", quality=7)
            for fr in frames:
                writer.append_data(fr)
            writer.close()
        else:
            raise ValueError(f"Unsupported video format: {ext}")

        if phase == 2:
            try:
                self._make_noise_videos(model, grid, out_dir, fps, filename)
            except Exception as e:
                print(f"[make_video] Warning: noise video failed with error: {e}")
        return path
    
    def _make_noise_videos(self, model, grid, out_dir, fps, filename):
        if getattr(self, "noise_model", None) is None:
            return None, None
        if getattr(self, "ebm", None) is None:
            return None, None

        base, ext = os.path.splitext(filename)
        if ext == "":
            ext = ".mp4"

        os.makedirs(out_dir, exist_ok=True)
        frame_dir_name = filename.replace(".mp4", "_noise_frames")
        frames_dir = os.path.join(out_dir, frame_dir_name)
        os.makedirs(frames_dir, exist_ok=True)

        nx = int(grid.get("nx", 100))
        ny = int(grid.get("ny", 100))
        nt = int(grid.get("nt", 100))

        # Spatial grid
        Xg, Yg = linspace_2d(
            self.rect.xa, self.rect.xb,
            self.rect.ya, self.rect.yb,
            nx, ny, self.rect.device
        )
        ts = torch.linspace(self.t0, self.t1, nt, device=self.rect.device)

        extent = [float(self.rect.xa), float(self.rect.xb),
                  float(self.rect.ya), float(self.rect.yb)]
        
        ref_std = float(self.running_std.item())
        R_range = 1 # ref_std * 5.0
        
        r_grid_np = np.linspace(-R_range, R_range, 200).astype(np.float32)
        r_grid_torch = torch.from_numpy(r_grid_np).to(self.device).view(-1, 1)
        
        pdf_ebm = None
        with torch.no_grad():
            r_input_scaled = r_grid_torch / ref_std
            
            log_q = self.ebm(r_input_scaled).squeeze(-1) # [200]
            m = log_q.max()
            q_unn = torch.exp(log_q - m)
            
            Z = torch.trapezoid(q_unn, r_grid_torch.squeeze())
            pdf_ebm = (q_unn / Z).cpu().numpy()
        
        ebm_filename = filename.replace(".mp4", "_ebm_pdf.npz")
        ebm_pdf_path = os.path.join(out_dir, ebm_filename)
        np.savez_compressed(
            ebm_pdf_path,
            r_grid=r_grid_np,          # x-axis grid (unscaled residual values)
            pdf_ebm=pdf_ebm,           # learned pdf on r_grid
            ref_std=np.float32(ref_std),
            R_range=np.float32(R_range),
        )

        # True noise pdf
        r_cpu = torch.from_numpy(r_grid_np).float()
        noise_scale = self.sigma_local
        print("Average noise scale:", noise_scale)
        pdf_true = (self.noise_model.pdf(r_cpu / noise_scale) / noise_scale).numpy()
        
        true_pdf_filename = filename.replace(".mp4", "_true_pdf.npz")
        true_pdf_path = os.path.join(out_dir, true_pdf_filename)
        np.savez_compressed(
            true_pdf_path,
            r_grid=r_grid_np,          # x-axis grid (unscaled residual values)
            pdf_true=pdf_true,         # true pdf on r_grid
            noise_scale=np.float32(noise_scale),
            R_range=np.float32(R_range),
        )

        frames = []

        model.eval()
        with torch.no_grad():
            for tval in ts:
                # Build full space-time grid
                T = torch.full_like(Xg, tval)
                XYT = torch.stack(
                    [Xg.reshape(-1), Yg.reshape(-1), T.reshape(-1)], dim=1
                )  # [nx*ny, 3]

                # True solution and prediction on full grid
                U_true = self.u_star(Xg, Yg, T)                  # [nx, ny]
                U_pred = model(XYT).reshape(nx, ny)              # [nx, ny]

                # Sample true noise on full grid (whole domain)
                eps_true_flat = self.noise_model.sample(nx * ny).to(self.rect.device)
                eps_true = eps_true_flat.view(nx, ny)            # [nx, ny]

                # Noisy observations and residuals
                Y_noisy = U_true + eps_true                      # [nx, ny]
                R_field = (Y_noisy - U_pred)                     # [nx, ny]

                # Flatten for 1D distributions
                eps_flat = eps_true.detach().cpu().numpy().reshape(-1)
                res_flat = R_field.detach().cpu().numpy().reshape(-1)

                # Range for plots / pdf grid
                max_val = max(
                    float(np.max(np.abs(eps_flat))) if eps_flat.size > 0 else 0.0,
                    float(np.max(np.abs(res_flat))) if res_flat.size > 0 else 0.0,
                    1e-3,
                )
                R_range = 1 # 1.5 * max_val

                # ---- Build figure ----
                fig, axes = plt.subplots(2, 2, figsize=(12, 12), dpi=120)
                fig.suptitle(f"Noise distributions at t = {float(tval):.4f}")

                # [0,0] True noise field ε*(x,y,t)
                im0 = axes[0, 0].imshow(
                    eps_true.cpu().numpy().T,
                    origin="lower",
                    extent=extent,
                    vmin=-R_range,
                    vmax=R_range,
                    aspect="auto",
                    cmap="coolwarm",
                )
                axes[0, 0].set_title("True noise field ε*(x,y,t)")
                axes[0, 0].set_xlabel("x")
                axes[0, 0].set_ylabel("y")
                fig.colorbar(im0, ax=axes[0, 0], fraction=0.046, pad=0.04)

                # [0,1] Residual field r(x,y,t)
                im1 = axes[0, 1].imshow(
                    R_field.cpu().numpy().T,
                    origin="lower",
                    extent=extent,
                    vmin=-R_range,
                    vmax=R_range,
                    aspect="auto",
                    cmap="coolwarm",
                )
                axes[0, 1].set_title("Residual field r(x,y,t) = y_noisy - u_pred")
                axes[0, 1].set_xlabel("x")
                axes[0, 1].set_ylabel("y")
                fig.colorbar(im1, ax=axes[0, 1], fraction=0.046, pad=0.04)

                # [1,0] Histograms of ε* and r on same axes
                axes[1, 0].hist(
                    eps_flat, bins=40, density=True,
                    alpha=0.5, label="true noise sample ε*",
                )
                axes[1, 0].hist(
                    res_flat, bins=40, density=True,
                    alpha=0.5, label="residual sample r",
                )
                axes[1, 0].set_xlim(-R_range, R_range)
                axes[1, 0].set_xlabel("value")
                axes[1, 0].set_ylabel("density")
                axes[1, 0].set_title("Empirical distributions over whole domain")
                axes[1, 0].legend(loc="upper right", fontsize=8)

                # [1,1] True pdf vs EBM pdf on same axes
                if pdf_true is not None:
                    axes[1, 1].plot(
                        r_grid_np, pdf_true,
                        'k-', lw=2,
                        label="True Noise Distribution",
                    )
                axes[1, 1].plot(
                    r_grid_np, pdf_ebm,
                    'b--', lw=2,
                    label="PDF learned by EBM",
                )
                axes[1, 1].set_title("True vs EBM noise pdf")
                axes[1, 1].legend(loc="upper right", fontsize=8)
                axes[1, 1].set_xlabel("value")
                axes[1, 1].set_ylabel("density")
                axes[1, 1].set_xlim(-R_range, R_range)

                fig.tight_layout(rect=[0, 0.03, 1, 0.95])
                
                # save PDF frame
                frame_path = os.path.join(frames_dir, f"t_{float(tval):.3f}.pdf")
                fig.savefig(frame_path, format='pdf', bbox_inches='tight')

                # Convert figure to frame
                fig.canvas.draw()
                w, h = fig.canvas.get_width_height()
                buf = np.frombuffer(fig.canvas.tostring_rgb(), dtype=np.uint8)
                frame = buf.reshape(h, w, 3)
                
                frames.append(frame.copy())
                plt.close(fig)

        if not frames:
            return None, None

        # Save video
        path_noise = os.path.join(out_dir, f"{base}_noise_dist{ext}")
        if ext == ".gif":
            imageio.mimsave(path_noise, frames, fps=fps)
        elif ext == ".mp4":
            writer = imageio.get_writer(path_noise, fps=fps, codec="libx264", quality=7)
            for fr in frames:
                writer.append_data(fr)
            writer.close()
        else:
            raise ValueError(f"Unsupported video format: {ext}")

        # For backward-compatibility, return (path_true, path_ebm) style if you want:
        return path_noise, None

    def evaluate_gate_performance(self, model, out_dir, filename_prefix=None):
        if not self.use_extra_noise:
            print("[Evaluate] Extra noise not used in this experiment. Skipping gate evaluation.")
            return
        
        if self.gate_module is None or self.ebm is None:
            print("[Evaluate] Gate or EBM not available. Skipping gate evaluation.")
            return

        print("[Evaluate] Analyzing Gate Performance on all measurement data...")
        
        plt.rcParams.update({
            "font.family": "serif",           # Serif fonts for body text
            "mathtext.fontset": "cm",         # Computer Modern for math (LaTeX look)
            "font.size": 12,
            "pdf.fonttype": 42,   # embed TrueType fonts (editable/selectable text)
            "ps.fonttype": 42,
            "axes.labelsize": 13,
            "axes.titlesize": 14,
            "xtick.labelsize": 11,
            "ytick.labelsize": 11,
            "legend.fontsize": 20,
            "axes.spines.top": False,
            "axes.spines.right": False,
        })
        
        model.eval()
        self.gate_module.eval()
        self.ebm.eval()
        
        # 1. Get Residuals for ALL data
        with torch.no_grad():
            pred = model(self.X_data)

            # Raw residuals [N, 2]
            residual = self.y_data - pred
            res_flat = residual.view(-1, 1)
            
            # 2. Standardization
            res_scaled = res_flat / self.running_std
            
            # 3. Get EBM Log-Likelihoods (Energy)
            log_q = self.ebm(res_scaled).squeeze(-1) # [2N]
            
            # 4. Get Gate Weights & Z-scores
            # We access gate internals to reproduce the Z-score logic for plotting
            mu = log_q.mean()
            sigma = log_q.std() + 1e-6
            z_scores = (log_q - mu) / sigma
            
            # Learned parameters
            alpha = torch.nn.functional.softplus(self.gate_module.cutoff_alpha).item()
            beta = torch.nn.functional.softplus(self.gate_module.steepness).item()
            
            # Calculate final weights [2N]
            weights = torch.sigmoid(beta * (z_scores + alpha))
            
            # Move to CPU
            z_cpu = z_scores.cpu().numpy()
            w_cpu = weights.cpu().numpy()
            
            # 5. Prepare Labels (Normal vs Outlier)
            N = self.y_data.shape[0]
            labels = np.zeros(N, dtype=int) # 0 = Normal
            
            if len(self.outlier_indices) > 0:
                outlier_idx = self.outlier_indices
                labels[outlier_idx] = 1 # 1 = Outlier
        
        # --- PLOT 1: Sigmoid Decision Boundary ---
        fig, ax = plt.subplots(figsize=(10, 6))
        
        # A. Plot Learned Sigmoid Curve
        # Generate z range for smooth curve
        z_grid = np.linspace(z_cpu.min() - 0.5, z_cpu.max() + 0.5, 500)
        w_curve = 1.0 / (1.0 + np.exp(-beta * (z_grid + alpha)))
        
        ax.plot(z_grid, w_curve, 'k--', linewidth=2.5, label=f'Learned Gate (α={alpha:.2f}, β={beta:.2f})')
        
        # B. Scatter Data Points
        # Normal Points (Green)
        mask_norm = (labels == 0)
        ax.scatter(z_cpu[mask_norm], w_cpu[mask_norm], c='green', alpha=0.3, s=17, label=f'Normal ({np.sum(mask_norm)} points)')
        
        # Outlier Points (Red)
        mask_out = (labels == 1)
        ax.scatter(z_cpu[mask_out], w_cpu[mask_out], c='red', alpha=0.6, s=17, label=f'Outlier ({np.sum(mask_out)} points)')
        
        # Decorate
        ax.axvline(-alpha, color='gray', linestyle=':', linewidth=2, label='Cutoff Threshold')
        ax.set_xlabel("Log-Likelihood (${z}$-score)", fontsize=20)
        ax.set_ylabel("Reliability Weight (${g_i}$)", fontsize=20)
        ax.legend(loc='upper left', fontsize=15)
        ax.grid(True, alpha=0.3, linewidth=2)
        
        save_path = os.path.join(out_dir, f"{filename_prefix}_gate_sigmoid_analysis.pdf")
        plt.savefig(save_path, format='pdf', bbox_inches='tight', pad_inches=0.02)
        plt.close(fig)
        
        # --- PLOT 2: Confusion Matrix ---
        preds = (w_cpu < 0.5).astype(int)
        
        cm = confusion_matrix(labels, preds)
        cm_sum = np.sum(cm)
        cm_perc = cm / cm_sum
        
        annots = np.empty_like(cm).astype(str)
        nrows, ncols = cm.shape
        for i in range(nrows):
            for j in range(ncols):
                c = cm[i, j]
                p = cm_perc[i, j] * 100
                if i == 0 and j == 0:
                    label = "TN"
                elif i == 0 and j == 1:
                    label = "FP"
                elif i == 1 and j == 0:
                    label = "FN"
                elif i == 1 and j == 1:
                    label = "TP"
                
                # Format: "1250\n(25.0%)"
                annots[i, j] = f"{c}\n({p:.1f}%)"

        fig, ax = plt.subplots(figsize=(6, 5))
        hm = sns.heatmap(cm, annot=annots, fmt='', cmap='Greens', ax=ax,
                    linewidths=1, linecolor='black',
                    cbar=False, square=True,
                    annot_kws={"size": 14, "weight": "regular"},
                    xticklabels=['Accepted', 'Rejected'],
                    yticklabels=['Normal', 'Outlier'])
        if hm.collections:
            hm.collections[0].set_rasterized(True)
        
        cm_path = os.path.join(out_dir, f"{filename_prefix}_gate_confusion_matrix.pdf")
        plt.savefig(cm_path, format='pdf', bbox_inches='tight', pad_inches=0.02,)
        plt.close(fig)
        
        print(f"[Evaluate] Plots saved to {out_dir}")
        return {
            "gate/sigmoid": save_path,
            "gate/confusion": cm_path
        }
