#!/usr/bin/env bash
set -euo pipefail

if [[ $# -lt 3 || $# -gt 5 ]]; then
  echo "Usage: $0 {mse|lad|orpinn_q29|pinn_ebm|pinn_ebm_weight10|pinn_ebm_equal_weight|napinn|napinn_lad|napinn_q29} SEED DEVICE [VARIANT_CONFIG] [SMOKE_STEPS]" >&2
  exit 2
fi

method="$1"
seed="$2"
device="$3"
variant="${4:-}"
smoke_steps="${5:-}"
case "$method" in
  mse|lad|orpinn_q29|pinn_ebm|pinn_ebm_weight10|pinn_ebm_equal_weight|napinn|napinn_lad|napinn_q29) ;;
  *)
    echo "Unknown method: $method" >&2
    exit 2
    ;;
esac

args=(
  python -m scripts.experiments.run_realpdebench
  --common-config configs/experiment/realpdebench_cylinder_common.yaml
  --model-config configs/model/mlp.yaml
  --exp-config "configs/experiment/realpdebench_cylinder_${method}.yaml"
  --seed "$seed"
  --device "$device"
)
if [[ -n "$variant" ]]; then
  args+=(--variant-config "$variant")
fi
if [[ -n "$smoke_steps" ]]; then
  args+=(--smoke-steps "$smoke_steps")
fi
"${args[@]}"
